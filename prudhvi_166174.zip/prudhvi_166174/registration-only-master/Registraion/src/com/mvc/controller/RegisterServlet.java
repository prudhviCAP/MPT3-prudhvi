package com.mvc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.RegisterBean;
import com.mvc.dao.RegisterDao;


@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String studentName = request.getParameter("studentName");
		 String studentDept = request.getParameter("studentDept");
		 String marks = request.getParameter("marks");
		 String phoneNumber = request.getParameter("phoneNumber");
		String percentage = request.getParameter("percentage");
		 
		 RegisterBean registerBean = new RegisterBean();
		
		 registerBean.setStudentName(studentName);
		 registerBean.setStudentDept(studentDept);
		 registerBean.setMarks(marks);
		 registerBean.setPhoneNumber(phoneNumber);
		 registerBean.setPercentage(percentage);
		 
		 RegisterDao registerDao = new RegisterDao();
		 
		 String userRegistered = registerDao.registerUser(registerBean);
		 if(userRegistered.equals("SUCCESS"))  
		 {
			 request.getRequestDispatcher("/Home.jsp").forward(request, response);
		 }
		 else   //On Failure, display a meaningful message to the User.
		 {
			 request.setAttribute("errMessage", userRegistered);
			 request.getRequestDispatcher("/Register.jsp").forward(request, response);
		 }
		 
		
	}

}
