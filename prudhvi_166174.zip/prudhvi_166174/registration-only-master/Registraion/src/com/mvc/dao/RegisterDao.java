package com.mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.mvc.bean.RegisterBean;
import com.mvc.util.DBConnection;

public class RegisterDao {
	 public String registerUser(RegisterBean registerBean)
	 {
		 String studentName = registerBean.getStudentName();
		 String studentDept = registerBean.getStudentDept();
		 String marks = registerBean.getMarks();
		 String phoneNumber = registerBean.getPhoneNumber();
		String percentage = registerBean.getPercentage();
	 
	 Connection con = null;
	 PreparedStatement preparedStatement = null;
	 
	 try
	 {
	 con = DBConnection.createConnection();
	 String query = ""; //Insert user details into the table 'USERS'
	 preparedStatement = con.prepareStatement("insert into student_details values (?,?,?,?,?)"); //Making use of prepared statements here to insert bunch of data
	 preparedStatement.setString(1, studentName);
	 preparedStatement.setString(2, studentDept);
	 preparedStatement.setString(3, marks);
	 preparedStatement.setString(4, phoneNumber);
	 preparedStatement.setString(5, percentage);
	 
	 int i= preparedStatement.executeUpdate();
	 
	 if (i!=0) 
	 return "SUCCESS"; 
	 }
	 catch(SQLException e)
	 {
		 System.err.println("exception is here");
	 e.printStackTrace();
	 }
	 
	 return "Something went wrong there..!";  // On failure, send a message from here.
	 }
}
