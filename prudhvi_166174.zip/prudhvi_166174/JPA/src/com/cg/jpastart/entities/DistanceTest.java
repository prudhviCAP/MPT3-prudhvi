package com.cg.jpastart.entities;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DistanceTest {

	public static void main(String[] args) {
		
		double dist =0;
		EntityManagerFactory factory = 
				Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Distance distance = new Distance();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter journey details...");
		
		System.out.println("enter source...");
		distance.setSource(sc.next());
		
		System.out.println("enter destination...");
		distance.setDestination(sc.next());
		
		System.out.println("enter distance in km ...");
		distance.setDistanceKm(sc.nextDouble());
		dist=distance.getDistanceKm();
		
		distance.setDistanceM(0);
		
		em.persist(distance);
		
		
		System.out.println("Added one journey to database.");
		
		em.getTransaction().commit();
		em.close();
		factory.close();
	}
}
