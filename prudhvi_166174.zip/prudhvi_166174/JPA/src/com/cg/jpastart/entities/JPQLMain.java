package com.cg.jpastart.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class JPQLMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory factory = 
				Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		String sql = "SELECT dis FROM Distance dis WHERE dis.distanceId=1";
		TypedQuery<Distance> query = (TypedQuery<Distance>) em.createQuery(sql);
		//List<Student> list = query.getResultList();
		/*for(Student obj : list)
		{
			System.out.println("id = "+obj.getStudentId());
			System.out.println("name = "+obj.getName());
		}*/
		Distance dis = (Distance) query.getSingleResult();
		System.out.println("id = "+dis.getDistanceId());
		System.out.println("distKm = "+dis.getDistanceKm());
		em.getTransaction().begin();
		String sql1 = "UPDATE distance dis SET dis.distanceM=:distKm WHERE dis.distanceId=:id";
		Query query1 = em.createQuery(sql1);
		query1.setParameter("distKm", dis.getDistanceKm()/1.2);
		query1.setParameter("id", 1);
		int row = query1.executeUpdate();
		System.out.println(row);
		
	}

}
